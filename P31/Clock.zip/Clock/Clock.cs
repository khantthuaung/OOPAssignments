using System.Security.Principal;
using CounterApp;
using SplashKitSDK;


namespace ClockApp
{
    public class Clock
    {
        private Counter _hour;
        private Counter _minute;
        private Counter _second;

        public Clock()
        {
            _hour = new Counter("Hour");
            _minute = new Counter("Minute");
            _second = new Counter("Second");
        }
        public void Tick()
        {
            IncrementSecond();
        }
        private void IncrementSecond()
        {
            _second.Increment();
            if (_second.Ticks == 60)
            {
                _second.Reset();
                IncrementMinute();
            }
        }
        private void IncrementMinute()
        {
            _minute.Increment();
            if (_minute.Ticks == 60)
            {
                _minute.Reset();
                IncrementHour();
            }
        }
        private void IncrementHour()
        {
            _hour.Increment();
            if (_hour.Ticks == 12)
            {
                _hour.Reset();
            }
        }

        public void Reset()
        {
            _hour.Reset();
            _minute.Reset();
            _second.Reset();
        }
        public string GetTime()
        {
            return $"{_hour:D2}:{_minute:D2}:{_second:D2}";
        }
    }
}